from flask import Flask, flash, render_template, request, Blueprint, url_for
from werkzeug.utils import secure_filename
from werkzeug.utils import redirect
bp = Blueprint('upload', __name__, url_prefix='/upload')

from flask import session
from pybo import db






# 업로드 HTML 렌더링
@bp.route('/upload')
def render_file():
    return render_template('upload/upload.html')

    #
    # @bp.route('/fileUpload', methods = ['GET', 'POST'])
    # def upload_file():
    #     # print(request.form.getlist("key"))
    # print(request.form.getlist("value"))

    if request.method == 'POST':
        # 이미지 받기 request.files[name]
        pic = request.files['pic']
        keys = request.form.getlist("key")
        values = request.form.getlist("value")
        # Key와 Value로 일괄적으로 받습니다.

        # 세션상에서 저장된 유저 아이디를 가져옵니다.
        user_id = session.get('user_id')

        print(user_id,"///")
        print(keys,"///")
        print(values,"///")

        pic.save(secure_filename(pic.filename))
        return redirect(url_for('auth.login'))

    #
    # if custom_email in confirm_email['email']:
    #
    #     directory_list = os.listdir(current_dir) # 현재 경로에 모든폴더 리스트
    #     image_dir = current_dir + custom_email +'/' # image\test@naver.com
    #
    #     # 신규 고객일 경우 (업로드가 처음)
    #     if custom_email not in directory_list:
    #         os.mkdir(image_dir)
    #         pic.save(image_dir + '1.png')
    #
    #     else:
    #         count_img = len(os.listdir(image_dir))
    #         new_filename = str(count_img + 1) + '.png'
    #         pic.save(image_dir + new_filename)
    #
    # metatag = {'image_path' : new_filename} # 이미지 경로, 초기화
    # for key, value in zip(keys, values):
    #     metatag[key] = value
    #
    # db.users.update_one({"email":custom_email}, {'$push':{"image":metatag}}) # update_one(조건문, 수정내용)
    # return jsonify(metatag), 200



# # 파일 업로드 처리
# @bp.route('/fileUpload', methods = ['GET', 'POST'])
# def upload_file():
#     form = ImageUploadForm()
#     if request.method == 'POST':
#         f = request.files['file']
#         tag1 = form.tag1.data
#         tag2 = form.tag2.data
#         tag3 = form.tag3.data
#         print(session.get('user_id'),"////////////////////////")
#         print(tag1,"////////////////////////")
#         # 저장할 경로 + 파일명
#         # f.save("./images/" + secure_filename(f.filename))
#         f.save(secure_filename(f.filename))
#         return 'uploads 디렉토리 -> 파일 업로드 성공!'



if __name__ == '__main__':
    # 서버 실행
    bp.run(debug = True)